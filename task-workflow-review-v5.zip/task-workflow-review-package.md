# بستهٔ بازبینی: Migration گردش کار تسک JibHR (نسخهٔ پنجم)

این بسته برای بازبینی مستقل **SQL و Security** آماده شده است. هیچ‌چیز اجرا نشده است:
- هیچ Migration یا Rollbackی اجرا نشده است.
- هیچ پایگاه داده‌ای (Local یا Remote) تغییر نکرده و هیچ داده‌ای دست نخورده است.
- Commit انجام نشده است.
- **مجوز اجرا هنوز صادر نشده است.**

## ۱. چه چیزی بازبینی می‌شود

| فایل | نقش | خط | SHA-256 |
|---|---|---|---|
| `docs/task-workflow-migration-draft.sql` | Migration (یک Transaction) | 2060 | `80736803f1ffaabbf0d3798c58a9452e9daee92dd271ed0994af4ca4c839d767` |
| `docs/task-workflow-rollback-draft.sql` | Rollback (یک Transaction) | 1193 | `51306f0b3730a9631dbd79443af1966fcd348a925b59757cfe007d56c3c0242e` |
| `docs/task-workflow-premigration-report.sql` | گزارش فقط‌خواندنی | 453 | `cb1d8b663c38f2d0753ce9ae7a357ca0a656920e5e98a72c1f01d2ef10fe46cb` |
| `docs/task-workflow-proposal.md` | طرح کامل، ماتریس مجوز و آزمون‌ها | — | `20575cfba308acee3e8ab3ff5e5211aad9d97fc70ca0ab594a049ba943b89700` |
| `docs/task-workflow.md` | رفتار نهایی برای کاربر و توسعه‌دهنده | — | `9f28229bee4d7c3e9d8e19535007573d0eb9641a8068a839330b1d07e8a027ae` |
| `scripts/task-workflow-migration/` | Generatorها، Dump ۱۴ تابع (`fndefs/`)، بررسی استاتیک | — | common `5dd09de9…`، gen_migration `2bd3b973…`، gen_report `73fe33bf…`، gen_rollback `45f3e4b4…`، static_check `c49c96db…`، dump_functions `0d0f1e17…` |

**هر سه فایل SQL تولیدشده هستند.**
- بدنهٔ توابع موجود عیناً `pg_get_functiondef` پایگاه دادهٔ Local است.
- هر ویرایش یک Patch دقیق است که باید دقیقاً یک بار منطبق شود.
- بازبینی بهتر است روی **Generator** (به‌خصوص `gen_migration.py` و `common.py`) و خروجی آن انجام شود.

## ۲. محیط (خوانده‌شده، نه فرض‌شده)

- PostgreSQL 17.11 (Supabase Local).
- PostgREST فقط schemaهای `public` و `graphql_public` را منتشر می‌کند. schema `app` داخلی است.
- `postgres` مالک اشیا است و **Superuser نیست** (BYPASSRLS دارد). `service_role` هم BYPASSRLS دارد.
- **Default Privileges واقعی:**
  - در `public`، تابع جدید EXECUTE برای `anon`، `authenticated` و `service_role` (و PUBLIC) می‌گیرد؛ جدول جدید ALL برای همان نقش‌ها.
  - در `app`، EXECUTE برای PUBLIC.
  - Migration همه را Revoke و صریحاً Grant می‌کند و پیش از Commit بررسی می‌کند.
- پیش از Migration، `service_role` روی `task_reviews`، `task_review_rounds` و `task_activity_events` مجوزهای TRUNCATE و TRIGGER دارد. Migration آن‌ها را می‌گیرد.
- بدنهٔ توابع فعلی CRLF دارد، چون فایل‌های Migration اصلی CRLF هستند. Rollback این بایت‌ها را عیناً بازمی‌گرداند.

## ۳. تصمیم‌های محصولی (همه تأییدشده)

| کد | تصمیم |
|---|---|
| D1 | «در حال انجام» از Workflow فعال خارج می‌شود. |
| D2 | «مسدود» یک Flag است، با دلیل، ثبت‌کننده و زمان. |
| D3 | Priority هرگز Status را تغییر نمی‌دهد. |
| D4 | دایرکتوری محدود اعضای پروژه؛ `profiles` گسترش نمی‌یابد. |
| D5 | مسئول، بازبین و همکار تسک پروژه‌ای باید عضو فعال باشند. |
| D6 | Backlog = «در صف انجام». |
| D7 | هیچ وضعیت «انجام‌نشده» یا «شروع‌نشده» وجود ندارد. |
| B1 | درخواست اصلاح دو فیلد الزامی دارد. |
| B2 | ورود به بررسی فقط با `submit_task_for_review`. |
| B3 | حذف عضوی که مسئول، بازبین یا همکار یک تسک باز است ممنوع است، همراه فهرست. |
| §9 | تسک شخصی: Scope فعلی، `created_by` مستقل، Audit. |
| `vvvvvvv` | مستثنا، با وضعیت ثابت. |
| `ttt` | **(۹ آبان)** `changes_requested` → `backlog`، با وضعیت ثابت. |
| §8.5 | **(۹ آبان)** در restricted، همکار حذف‌شده دسترسی ندارد؛ تاریخچه حذف نمی‌شود. |

مدل نهایی:
- **وضعیت‌ها:** در صف انجام ← در حال بررسی ← انجام‌شده یا رد نهایی.
- **نیازمند اصلاح:** تصمیم بازبین که تسک را به «در صف انجام» برمی‌گرداند.
- **نسخه:** هر ارسال یک دور است و Snapshot تغییرناپذیر دارد.

## ۴. وضعیت دادهٔ واقعی (Pre-migration Report، فقط‌خواندنی، ۹ آبان)

- **R1:** ۵ Workflow، همه default. هیچ Workflow سفارشی وجود ندارد.
- **R3 Plan:**

  | تسک | تصمیم |
  |---|---|
  | `ttt` (`f4725489…`) | changes_requested → backlog |
  | «لندینگ باگ بانتی» (`30445be8…`) | approved → done |
  | `rgdfdgf` (`47d8d5a3…`) | excluded |
  | `vvvvvvv` (`cf890d3d…`) | excluded |

  هیچ مورد مبهمی وجود ندارد.
- **R4 Integrity:** `assignee_not_member` = rgdfdgf و `personal_created_for_other` = vvvvvvv. هر دو فقط گزارش می‌شوند و Migration آن‌ها را تغییر نمی‌دهد.
- **R5:** وضعیت ۱۰ستونی چهار تسک ثابت‌شده.
- **R7 (مقایسهٔ Guard: workflow، plan، pinned_state و integrity): خالی.**
- **سابقه:** یک تغییر واقعی داده (`ttt` از todo به changes_requested توسط مسئولش در برنامه) با همین مکانیزم کشف شد و پس از تأیید ثبت شد.

## ۵. خلاصهٔ Migration

| § | محتوا |
|---|---|
| 0 | `lock_timeout`؛ Lock جدول‌ها؛ Plan، طبقه‌بندی، Integrity و وضعیت ثابت‌شده از **همان متن SQL گزارش**؛ Guard (`premigration_mismatch` با DETAIL) |
| 1–2 | جدول‌های دفتری (Log با `blocked_at_set`، before/after وضعیت‌ها، انتقال‌ها با مقادیر)؛ Flag مسدود؛ `task_block_events`؛ ستون‌های نسخه و Snapshot (`snapshot_status`، `submitted_by_source`) با CHECK؛ نام تاریخی تصمیم؛ `task_revision_requests` با FK ترکیبی |
| 3 | ۱۲ تابع داخلی INVOKER و ۴ تابع Trigger |
| 4 | تاریخچهٔ قدیمی: فقط شناسهٔ ارسال‌کننده از Event؛ Snapshot «در دسترس نیست»؛ هیچ نام امروزی به‌عنوان نام گذشته |
| 5–6 | Report، جابه‌جایی قطعی، Workflowهای default (نام، ترتیب، غیرفعال‌سازی، ۶ انتقال) |
| 7 | ۷ RPC جدید؛ `decide_task(p_task, p_decision, p_round, p_reason, p_what, p_changes, p_override_reason)` |
| 8 | ۱۳ تابع موجود با Patch (فهرست در طرح، بخش ۷.۱) |
| 9 | Triggerهای تغییرناپذیری ردیفی، ۵ Trigger `BEFORE TRUNCATE`، Constraint Trigger B1 |
| 10–11 | RLS جدول‌های جدید؛ Privileges صریح |
| 12 | خودآزمایی ACL و TRUNCATE پیش از Commit |

## ۶. Rollback در یک نگاه

- **بازگرداندن مشروط** (فقط چیزهایی که پس از Migration دست نخورده‌اند):
  - Status تسک؛ برای تسک «مسدود»، فقط با Flag دست‌نخوردهٔ Migration؛
  - نام، ترتیب و `is_active` وضعیت‌ها؛
  - انتقال‌ها با همان شناسه و مقادیر.
- **۱۴ بدنهٔ اصلی** با بایت‌های اصلی و Grantهای قبلی؛ خودآزمایی MD5 پیش از Commit.
- **حذف نمی‌شود:** تاریخچه، Snapshotها، درخواست‌های اصلاح، Eventها و Logها. Triggerهای تغییرناپذیری، TRUNCATE و Revokeها می‌مانند. فقط Constraint Trigger B1 حذف می‌شود.
- **گزارش سه‌بخشی:** Restored، Kept (با دلیل)، Kept by policy.

## ۷. بررسی‌های انجام‌شده (بدون اجرای Migration)

| بررسی | نتیجه |
|---|---|
| Parser واقعی PostgreSQL (`pglast` / libpg_query) | Migration ۱۵۱ دستور و ۲۹ بدنهٔ PL/pgSQL؛ Rollback ۸۰ و ۱۵؛ Report ۱۰ — بدون خطا |
| Lint امنیتی | همهٔ DEFINERها `search_path = ''`؛ Revoke برای هر تابع جدید؛ بدون Grant به PUBLIC یا anon؛ بدون تغییر `profiles` |
| ارجاع‌ها | ۸۱ ارجاع `public.*` و `app.*` با Catalog زنده یا اشیای همان فایل |
| Rollback | MD5 هر ۱۴ بدنه = `prosrc` زنده |
| Report | اجرای فقط‌خواندنی؛ R7 خالی |
| Generator | Patchهای دقیق؛ Python با `-W error::SyntaxWarning` بدون هشدار |
| آزمون‌های Flutter موجود | ۲۲۰ قبول |

**محدودیت:** خطاهای زمان اجرا، ترتیب قفل‌ها و رفتار هم‌زمانی فقط با آزمون‌های طرح، بخش ۱۳، اثبات می‌شوند. آن آزمون‌ها اجرای Migration را لازم دارند.

## ۸. نقاطی که بازبینی دقیق‌تر لازم دارند

1. **هم‌زمانی تصمیم:**
   - ترتیب قفل در `decide_task` و `review_update_task`: تسک `FOR UPDATE`، سپس دور باز `FOR UPDATE` با `app.open_round`.
   - قید یکتای `task_reviews.round_id`.
   - رفتار `stale_round` وقتی دور بین خواندن UI و فراخوانی بسته یا عوض شده باشد.
2. **حذف عضو در برابر تخصیص:**
   - `app.require_active_member` ردیف عضویت را `FOR SHARE` قفل می‌کند و `remove_project_member` آن را `FOR UPDATE`.
   - آیا در Read Committed برای هر سه مسیر (مسئول، بازبین، همکار) شکاف TOCTOU باقی می‌ماند؟
3. **Override زیرتسک در تأیید:** `p_override_reason` مستقل از `p_reason` است، فقط برای `tasks.manage.project` یا `tasks.view.all`. Audit و Event همان مسیر `transition_task` را دارند.
4. **INVOKER بودن توابع داخلی:** این توابع داخل RPCهای DEFINER اجرا می‌شوند. EXECUTE از همهٔ نقش‌های کلاینت گرفته شده است. آیا مسیر فراخوانی دیگری (مثلاً از سیاست RLS) وجود دارد؟
5. **تغییرناپذیری در برابر TRUNCATE، TRIGGER و REFERENCES:** با `has_table_privilege` و Triggerهای Statement. تنها استثنا حالت replica مخصوص Superuser است که فقط در پاک‌سازی QA محلی استفاده می‌شود.
6. **سخت‌گیری `app.task_visible_directly`:** فقط مسیر همکار در restricted تغییر کرده است. مسیرهای مسئول، مدیر و بازبین بدون تغییر هستند.
7. **Guard:** مقایسهٔ ردیف‌به‌ردیف با `EXCEPT` در هر دو جهت؛ مدیریت NULL در `EXCEPT` (NULLها برابر محسوب می‌شوند)؛ Cast انواع.
8. **سازگاری Rollback با کد قدیمی:**
   - پیش‌فرض‌های `unavailable` و CHECKها در برابر درج‌های `transition_task` و `decide_task` قدیمی.
   - ماندن Triggerهای تغییرناپذیری پس از Rollback.
9. **CRLF و MD5:** خودآزمایی Rollback روی `md5(prosrc)` تکیه دارد.

## ۹. مراحل پس از بازبینی (فقط با مجوز)

1. اصلاح Generator بر اساس یافته‌ها، تولید دوباره، بررسی استاتیک و R7.
2. پشتیبان‌گیری Local (`scripts/backup.ps1`).
3. اجرای Report و تأیید خالی بودن R7.
4. Migration روی Local.
5. آزمون‌های M، A، C، V و R (طرح، بخش ۱۳)؛ سپس به‌روزرسانی UI.
