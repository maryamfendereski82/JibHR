# طرح نهایی بک‌اند: Workflow، چرخهٔ بررسی، نسخه‌ها و یکپارچگی تخصیص

| | |
|---|---|
| وضعیت | **Draft نسخهٔ پنجم (نهایی‌شده با دو تصمیم بازبینی ۹ آبان)، برای بازبینی SQL و Security.** مجوز اجرای Migration هنوز صادر نشده است. بستهٔ بازبینی: [task-workflow-review-package.md](task-workflow-review-package.md). |
| اجرا | هیچ Migration یا Rollbackی اجرا نشده است. هیچ پایگاه داده‌ای تغییر نکرده، هیچ داده‌ای دست نخورده و Commit انجام نشده است. |
| فایل‌ها | [task-workflow-migration-draft.sql](task-workflow-migration-draft.sql) · [task-workflow-rollback-draft.sql](task-workflow-rollback-draft.sql) · [task-workflow-premigration-report.sql](task-workflow-premigration-report.sql) (فقط‌خواندنی) · [task-workflow.md](task-workflow.md) (رفتار نهایی) |
| تولید | [scripts/task-workflow-migration/](../scripts/task-workflow-migration/README.md): Generatorها، Dump توابع و بررسی استاتیک. SQLها را دستی ویرایش نکنید. |

## ۱. تصمیم‌ها

| کد | تصمیم |
|---|---|
| D1 | «در حال انجام» از Workflow فعال خارج می‌شود. |
| D2 | «مسدود» یک Flag است. |
| D3 | Critical خودکار وارد بررسی نمی‌شود. |
| D4 | دایرکتوری محدود اعضا. |
| D5 | عضویت اجباری مسئول، بازبین و همکار. |
| D6 | «در صف انجام». |
| D7 | هیچ وضعیت «انجام‌نشده» یا «شروع‌نشده» وجود ندارد. |
| B1 | درخواست اصلاح دو فیلد الزامی دارد. |
| B2 | ورود به بررسی فقط با Submit. |
| B3 | حذف عضو دارای تسک باز ممنوع است. |
| §9 | تسک شخصی: `created_by` مستقل از مسئول؛ Scope فعلی؛ Audit. |
| `vvvvvvv` | از انتقال مستثنا می‌ماند و Guard وضعیت دقیق آن را کنترل می‌کند (تأییدشده؛ بدون تغییر). |
| `ttt` | **تأییدشده (۹ آبان):** از `changes_requested` به `backlog` منتقل می‌شود. Guard وضعیت فعلی کامل آن و این نگاشت را کنترل می‌کند؛ هر تغییر Migration را متوقف می‌کند. |
| §8.5 | **تأییدشده (۹ آبان):** سخت‌گیری `app.task_visible_directly`؛ همکار حذف‌شده در پروژهٔ restricted دسترسی ندارد؛ تاریخچه حذف نمی‌شود؛ سایر نقش‌ها بدون تغییر. |

## ۲. تغییرات نسخه‌های چهارم و پنجم

**نسخهٔ پنجم:** دو تصمیم بالا ثبت شد. Guard (c) و R5/R7 اکنون وضعیت کامل **چهار تسک ثابت‌شده** را مقایسه می‌کنند: دو تسک مستثنا و دو تسکی که منتقل می‌شوند (`ttt` و «لندینگ باگ بانتی»)، با ۱۰ ستون: عنوان، شخصی بودن، وضعیت، approval_state، approval_required، مسئول، سازنده، بازبین، بایگانی‌نبودن، شناسه.

**نسخهٔ چهارم (پاسخ بازبینی):**

| بند | تغییر |
|---|---|
| A | در `decide_task`، تأیید همان قاعدهٔ `app.task_children_block_done` را اجرا می‌کند. بدون Override: `subtasks_incomplete`. Override فقط برای `tasks.manage.project` یا `tasks.view.all`، با `p_override_reason` مستقل از `p_reason`. Audit `task.override_subtasks` و رویداد `task.override` همان مسیر `transition_task` را دارند. رویداد `task.subtask_done` برای والد هم ثبت می‌شود. |
| B | `remove_project_member` نقش‌های **مسئول، بازبین اختصاصی و همکار** را در تسک‌های باز بررسی می‌کند. DETAIL شامل `by_role` و نقش هر تسک است. `project_member_open_tasks` فهرست کامل را با نقش‌ها می‌دهد. `app.can_decide_task` عضویت فعال بازبین اختصاصی تسک پروژه‌ای را می‌خواهد. Audit برای تغییر مسئول پروژه (`task.reassign`)، تغییر بازبین (`task.reviewer_change`) و حذف همکار (`task.collaborator_remove`، در `remove_task_collaborator`). **سخت‌گیری روی دسترسی:** `app.task_visible_directly` (بخش ۸.۵). |
| C | `review_update_task` و `decide_task` روی تسک مسدود `task_blocked` می‌دهند. پس از `clear_task_blocked` همان دور و همان نسخه ادامه پیدا می‌کند و Status تغییر نمی‌کند. |
| D | `id` به مقایسهٔ `app.protect_review_round` اضافه شد (`round_immutable`). |
| E | جدول‌های تاریخی جدید برای `authenticated` و `service_role` فقط SELECT دارند. از سه جدول تاریخی موجود، TRUNCATE، TRIGGER و REFERENCES از `service_role` و بقیه گرفته شد. پنج Trigger `BEFORE TRUNCATE` برای همهٔ نقش‌ها، حتی مالک، اضافه شد. خودآزمایی پیش از Commit همهٔ این‌ها را با `has_table_privilege` بررسی می‌کند. |
| F | **Rollback:** تسک مسدود فقط وقتی برمی‌گردد که همان Flag Migration دست‌نخورده باشد (زمان دقیق ثبت‌شده در Log، `blocked_by` تهی، همان دلیل). Event رفع انسداد فقط در همان حالت ثبت می‌شود. انتقال اضافه‌شده فقط وقتی حذف می‌شود که ردیف با همان شناسه و همان مقادیر هنوز وجود داشته باشد. گزارش در سه بخش است: بازگردانده‌شده، حفظ‌شده با دلیل، و حفظ‌شده به حکم سیاست. |
| G | R7 اکنون وضعیت دقیق دو تسک استثنا را با **همان SQL و همان ستون‌های** Guard (c) مقایسه می‌کند. |
| H | قاعدهٔ بازگشایی «رد نهایی» در [task-workflow.md](task-workflow.md) با منطق واقعی `transition_task` یکسان شد. |
| I | ماتریس آزمون به‌روز شد (بخش ۱۳). |

## ۳. Pre-migration Report: انتظار در برابر وضعیت واقعی

اسکریپت دوباره در `begin transaction read only … rollback` روی پایگاه دادهٔ Local اجرا شد.

| بخش | وضعیت واقعی | انتظار Guard | نتیجه |
|---|---|---|---|
| R1 طبقه‌بندی | ۵ Workflow، همه default | همین ۵ شناسه، بدون Workflow سفارشی | برابر |
| R3 Plan | `ttt`: **changes_requested** → backlog · «لندینگ باگ بانتی»: approved → done · `rgdfdgf` و `vvvvvvv`: excluded | همین ۴ ردیف | برابر (پس از به‌روزرسانی، پایین) |
| R4 Integrity | `assignee_not_member`: rgdfdgf · `personal_created_for_other`: vvvvvvv | همین دو ردیف | برابر |
| R5 وضعیت تسک‌های ثابت‌شده | vvvvvvv: شخصی، approved، not_required، approval=false، reviewer = مسئول · rgdfdgf: پروژه‌ای، backlog، pending، approval=true · **ttt: شخصی، changes_requested، not_required، approval=false، مسئول = سازنده** · **لندینگ باگ بانتی: شخصی، approved، approved، approval=true، مسئول = سازنده** · همه بایگانی‌نشده | ستون به ستون | برابر |
| R7 | **خالی**؛ شامل workflow، plan، **pinned_state** (۴ تسک) و integrity | خالی | برابر |

**یک تغییر واقعی در داده، که Guard آن را گرفت:**
- `ttt` (`f4725489…`) در گزارش ۸ آبان در `todo` بود.
- اجرای امروز R7 تفاوت را نشان داد.
- طبق `task_activity_events`، مسئول خود تسک در ۹ آبان آن را از برنامه جابه‌جا کرده است: todo → in_progress → in_review → changes_requested. تسک نیاز به تأیید ندارد و Workflow قدیمی این را اجازه می‌دهد.
- نگاشت آن همچنان قطعی است (changes_requested → backlog). ردیف انتظار در `common.py` به‌روز و علت آن در کد ثبت شد.
- **این ردیف در بازبینی ۹ آبان تأیید شد.**
- اگر پیش از اجرا داده دوباره تغییر کند، Guard اجرا را متوقف می‌کند (همان رفتار مطلوب).

## ۴. Review Version و تصمیم

### امضای جدید

`decide_task(p_task, p_decision, p_round, p_reason, p_what, p_changes, p_override_reason)`. `p_round` پیش‌فرض ندارد و NULL پذیرفته نمی‌شود.

### ترتیب اعتبارسنجی، همه زیر قفل

1. `FOR UPDATE` روی تسک.
2. مجوز: `can_view_task` و `can_decide_task`. بازبین اختصاصی تسک پروژه‌ای باید عضو فعال باشد.
3. دور باز `FOR UPDATE`. اگر `p_round` دور باز نباشد: `stale_round`.
4. دسته `in_review`، `approval_state = pending` (وگرنه `invalid_state`)، و **مسدود نبودن** (وگرنه `task_blocked`).
5. **تأیید:** قاعدهٔ زیرتسک اجباری. Override فقط مدیر و با دلیل مستقل.
6. وضعیت مقصد باید در Workflow باشد (وگرنه `workflow_incomplete`).
7. اعمال ویرایش‌های بازبین (`p_changes`).
8. درج تصمیم؛ قید یکتای `round_id` (بازنده: `already_decided`، و کل Transaction برمی‌گردد).
9. درخواست اصلاح، Override، Status، اعلان‌های فعلی، Event و Audit.

### نسخه‌های قدیمی

`snapshot_status = 'unavailable'`، بدون Snapshot و بدون نام امروز. قیدهای CHECK همین را اجبار می‌کنند.

## ۵. Guard

Guard این‌ها را **ردیف به ردیف** مقایسه می‌کند:
- (a) Workflowها
- (b) Plan: شناسه، مبدأ، مقصد، تصمیم
- (c) وضعیت دقیق چهار تسک ثابت‌شده (دو مستثنا و دو منتقل‌شونده)، از همان SQL که R5 و R7 را می‌سازد
- (d) یافته‌های Integrity

موارد مبهم (مسدود بدون Event قابل بازیابی، in_review بدون دور، approved بدون تأیید) و Workflow سفارشی اجرا را متوقف می‌کنند.

## ۶. Workflow سفارشی

بدون تغییر نسبت به نسخهٔ سوم:
- Migration آن را تغییر نمی‌دهد و Guard اجرا را متوقف می‌کند.
- قواعد B2 و عضویت و مسدود برای همهٔ Workflowها برقرار است.
- Workflow ناقص `workflow_incomplete` می‌دهد و هیچ تغییر نیمه‌کاره‌ای نمی‌ماند.
- `save_workflow_status` شامل `category_retired` و `status_required` است.

## ۷. توابعی که واقعاً تغییر می‌کنند

### ۷.۱ توابع موجود (بدنهٔ Dump به‌علاوهٔ Patch دقیق؛ امضا و ACL بدون تغییر) — ۱۳ تابع

| تابع | ویرایش |
|---|---|
| `public.create_task` | عضویت فعال مسئول و بازبین (پروژه)؛ فعال بودن مسئول و بازبین (شخصی)؛ Event `on_behalf`؛ Audit `task.create_for` |
| `public.update_task` | `invalid_state` برای تغییر سیاست تأیید با دور باز. **مسئول:** عضویت و Audit `task.reassign` (پروژه)؛ Scope و Audit `task.reassign_for` (شخصی). **بازبین:** عضویت یا فعال بودن، و Audit `task.reviewer_change` |
| `public.transition_task` | `use_decide`، `use_submit`، `task_blocked`. دور و اعلان‌های بررسی عیناً به `submit_task_for_review` منتقل شدند. بازگشایی → `pending` |
| `public.add_task_collaborator` | عضویت فعال همکار (قفل share روی ردیف عضویت) |
| `public.remove_task_collaborator` | **جدید در این نسخه:** Audit `task.collaborator_remove` (Event از قبل وجود داشت) |
| `public.remove_project_member` | `FOR UPDATE` روی ردیف عضویت؛ `member_has_open_tasks` برای هر سه نقش، با DETAIL `{total, hidden, by_role, tasks[≤50] با roles}` |
| `app.task_visible_directly` | **سخت‌گیرانه، تأییدشده (بخش ۸.۵):** مسیر همکار در پروژهٔ restricted فقط با عضویت فعال؛ ردیف‌های `task_collaborators` حذف نمی‌شوند |
| `public.save_workflow_status` | `category_retired` و `status_required` |
| `app.seed_workflow` | چهار وضعیت و شش انتقال |
| `public.project_sprint_counts`، `public.project_milestone_counts`، `public.set_sprint_status`، `public.work_analytics` | «مسدود» = `category = 'blocked'` یا `blocked_at is not null` |

**بررسی‌شده و بدون تغییر:**
- `dashboard_personal`، `app.dashboard_summary_v1`، `dashboard_projects`: معیار «مسدود» ندارند. «نیازمند اصلاح» را از `approval_state` می‌خوانند.
- `app.task_counts_complete`، `app.task_children_block_done`، `set_task_labels`.

### ۷.۲ جایگزین‌شده

`public.decide_task(uuid, text, text)` حذف می‌شود و `public.decide_task(uuid, text, uuid, text, text, jsonb, text)` جای آن را می‌گیرد. اعلان‌های فعلی عیناً حفظ شده‌اند.

### ۷.۳ RPCهای جدید (DEFINER؛ `search_path = ''`)

`project_member_directory`، `project_member_open_tasks` (اکنون با `roles`)، `submit_task_for_review`، `review_update_task`، `decide_task`، `set_task_blocked`، `clear_task_blocked`.

### ۷.۴ توابع داخلی (INVOKER؛ فقط مالک)

۱۲ تابع کمکی (`app.can_decide_task` با شرط عضویت؛ `app.open_tasks_of_member` با نقش‌ها) و ۴ تابع Trigger (`app.protect_review_round` با `id`).

فهرست تولیدشده: `scripts/task-workflow-migration/changed-functions.txt`.

## ۸. ماتریس مجوز توابع و RLS

### ۸.۱ Default Privileges واقعی

بدون تغییر نسبت به نسخهٔ سوم:
- در `public`، اشیای جدید EXECUTE یا ALL برای `anon` و `authenticated` می‌گیرند.
- در `app`، EXECUTE برای PUBLIC.
- PostgREST فقط `public` را منتشر می‌کند.
- `postgres` Superuser نیست.

**قبل از Migration، `service_role` روی `task_reviews`، `task_review_rounds` و `task_activity_events` مجوزهای TRUNCATE و TRIGGER دارد** (بررسی‌شده با `has_table_privilege`).

### ۸.۲ توابع

| تابع | PUBLIC | anon | authenticated | service_role |
|---|---|---|---|---|
| ۷ RPC جدید | ✗ | ✗ | ✓ | ✓ |
| ۱۱ تابع public تغییرکرده | ✗ | ✗ | ✓ (مثل امروز) | ✓ |
| `app.seed_workflow`، `app.task_visible_directly` | ✗ | ✗ | ✗ | ✓ (مثل امروز) |
| ۱۶ تابع داخلی و Trigger جدید | ✗ | ✗ | ✗ | ✗ |

### ۸.۳ جدول‌ها

| جدول | anon | authenticated | service_role | RLS خواندن | حذف و تغییر |
|---|---|---|---|---|---|
| `task_revision_requests`، `task_block_events` | ✗ | SELECT | **SELECT** | `can_view_task` | فقط RPCها (مالک)؛ UPDATE، DELETE و TRUNCATE با Trigger رد می‌شوند |
| `task_review_rounds`، `task_reviews`، `task_activity_events` | ✗ | مثل امروز | مثل امروز **منهای TRUNCATE، TRIGGER و REFERENCES** | سیاست‌های فعلی | Triggerهای ردیفی و Statement |
| ۵ جدول دفتری | ✗ | ✗ | ✗ | RLS بدون سیاست | فقط Migration و Rollback |
| `profiles` | بدون تغییر | بدون تغییر | بدون تغییر | `profiles_select` بدون تغییر | — |

**ادعای تغییرناپذیری با دسترسی واقعی می‌خواند:**
- هیچ نقش غیرمالک TRUNCATE یا TRIGGER یا REFERENCES روی جدول‌های تاریخی ندارد.
- `service_role` روی جدول‌های تاریخی جدید فقط SELECT دارد.
- Triggerهای `BEFORE TRUNCATE` حتی مالک (postgres، که Superuser نیست) را متوقف می‌کنند.
- فقط حالت replica مخصوص Superuser آن‌ها را دور می‌زند، که منحصر به اسکریپت‌های پاک‌سازی QA محلی است.
- خودآزمایی بخش ۱۲ Migration همهٔ این‌ها را پیش از Commit بررسی می‌کند (`acl_check_failed`).

### ۸.۴ نقش‌ها در RPCها

| Action | مسئول | عضو | بازبین پروژه | مدیر پروژه | تأییدکنندهٔ تیم | `tasks.manage.project` | غیرعضو یا عضو حذف‌شده |
|---|---|---|---|---|---|---|---|
| ارسال برای بررسی | ✓ | ✗ | ✗ | ✓ | ✓ | ✓ | ✗ |
| تصمیم | ✗* | ✗ | ✓ | ✓ | ✓ (شخصی) | ✗* | ✗ (حتی اگر بازبین اختصاصی بوده) |
| Override زیرتسک هنگام تأیید | ✗ | ✗ | ✗ | ✓** | ✗** | ✓ | ✗ |
| ویرایش بازبین (متن، اولویت، مهلت، برچسب) | ✗ | ✗ | ✓ | ✓ | ✓ | — | ✗ |
| ویرایش بازبین (مسئول، همکار) | ✗ | ✗ | ✗ | ✓ | ✗ | ✓ | ✗ |
| مسدود و رفع | ✓ | ✗ | ✗ | ✓ | ✓ | ✓ | ✗ |
| حذف عضو | — | — | — | ✓ (`can_edit_project`) | — | — | ✗ |

\* مگر بازبین واجد شرایط هم باشد.
\*\* Override به `tasks.manage.project` یا `tasks.view.all` نیاز دارد. نقش فعلی مدیر پروژه `tasks.manage.project` دارد.

### ۸.۵ سخت‌گیری در `app.task_visible_directly` — **تأییدشده در بازبینی ۹ آبان**

- این تابع بخشی از مسیر RLS است.
- تغییر: در پروژهٔ restricted، مسیر **همکار** فقط تا زمانی دسترسی می‌دهد که همکار عضو فعال پروژه باشد. **دسترسی گسترش نمی‌یابد، فقط محدود می‌شود.**
- **دلیل:** بند B. حذف عضو تنها با تسک‌های باز مسدود می‌شود. بدون این تغییر، عضو حذف‌شده از راه ردیف‌های همکار روی تسک‌های **بسته** همچنان دسترسی restricted دارد.
- **جایگزین بدون تغییر RLS:** حذف خودکار ردیف‌های همکار تسک‌های بسته هنگام حذف عضو، با Event و Audit. این داده را تغییر می‌دهد و پیشنهاد نمی‌شود.
- مسیر **مسئول** در restricted بدون تغییر می‌ماند: مسئول سابق تسک‌های بستهٔ خودش را می‌بیند. اگر این هم باید محدود شود، تصمیم جداگانه لازم است.

## ۹. تسک شخصی

بدون تغییر نسبت به نسخهٔ سوم:
- Scope فعلی `create_task`.
- `created_by` مستقل از مسئول.
- Audit `task.create_for` و `task.reassign_for`.
- `assignee_out_of_scope`.
- RLS دیدن بدون تغییر.

## ۱۰. Rollback

| مورد | سیاست |
|---|---|
| Status تسک | فقط اگر هنوز همان مقصد Migration باشد. برای تسکی که از Status «مسدود» آمده، باید **همان Flag Migration** دست‌نخورده باشد: زمان برابر `blocked_at_set`، بدون `blocked_by`، همان دلیل. اگر کاربر رفع انسداد کرده یا دوباره مسدود کرده، با دلیل `unblocked_by_person` یا `flag_changed_by_person` حفظ می‌شود. |
| Event رفع انسداد | فقط وقتی Rollback واقعاً Flag Migration را برمی‌دارد. |
| وضعیت‌ها | فقط اگر ردیف هنوز برابر `after` ثبت‌شده باشد. |
| انتقال‌های اضافه‌شده | فقط اگر ردیف با همان شناسه، همان Workflow، همان مبدأ و همان مقصد هنوز وجود داشته باشد. حذف یا تغییر بعدی مدیر حفظ می‌شود (`removed_after_migration` یا `changed_after_migration`). |
| توابع | **۱۴ بدنهٔ اصلی** (از جمله `remove_task_collaborator` و `task_visible_directly`) با بایت‌های اصلی، Grantهای قبلی، و خودآزمایی MD5. |
| تاریخچه و محافظت | دورها، Snapshotها، تصمیم‌ها، درخواست‌ها و Eventها **حذف نمی‌شوند**. Triggerهای تغییرناپذیری، Triggerهای TRUNCATE و Revokeهای TRUNCATE، TRIGGER و REFERENCES **می‌مانند**. فقط Constraint Trigger B1 حذف می‌شود. |
| گزارش | سه بخش: Restored، Kept (با دلیل)، Kept by policy. ثبت در `workflow_rollback_runs`. |

## ۱۱. بررسی استاتیک SQL (بدون اجرا)

| بررسی | نتیجه |
|---|---|
| تجزیهٔ دستورها | Migration: ۱۵۱ · Rollback: ۸۰ · Report: ۱۰ — **همه تجزیه شدند** |
| بدنه‌های PL/pgSQL | Migration: ۲۹ · Rollback: ۱۵ — **همه تجزیه شدند** |
| `search_path` و Revoke | همهٔ DEFINERها `search_path = ''` دارند. هر تابع جدید Revoke دارد. هیچ Grant عمومی، Grant روی تابع داخلی یا تغییر روی `profiles` وجود ندارد. |
| ارجاع‌ها | ۸۱ ارجاع یکتا با Catalog زنده تطبیق داده شد. |
| Placeholder | هیچ |
| Rollback | MD5 هر **۱۴** بدنه با پایگاه دادهٔ زنده برابر است. همهٔ توابع جدید حذف می‌شوند، به‌جز توابع Trigger حفظ‌شده. |
| Report و Guard | R7 خالی (فقط‌خواندنی) |
| Generator | همهٔ Patchها دقیقاً یک بار منطبق شدند. Python با `-W error::SyntaxWarning` بدون هشدار اجرا شد. |

**محدودیت:** خطای زمان اجرا و رفتار هم‌زمانی فقط با بخش ۱۳ تأیید می‌شود.

## ۱۲. آزمون‌های ایزوله (انجام‌شده، بدون Migration)

| # | آزمون | نتیجه |
|---|---|---|
| I1 | تجزیه | ✓ |
| I2 | Lint امنیتی | ✓ |
| I3 | ارجاع‌ها | ✓ |
| I4 | R7 خالی؛ شامل excluded_state و یک تغییر واقعی دادهٔ کشف‌شده | ✓ |
| I5 | MD5 Rollback | ✓ |
| I6 | Patchهای دقیق | ✓ |
| I7 | آزمون‌های Flutter (۲۲۰) | ✓ |
| I8 | حضور هر بند بازبینی در SQL تولیدشده (جست‌وجوی دقیق متن: Override، `task_blocked` در هر دو مسیر بازبینی، `new.id`، Triggerهای TRUNCATE، Revokeها، نقش همکار، شرط عضویت بازبین، `blocked_at_set`، شرط مقادیر انتقال) | ✓ |

## ۱۳. آزمون‌هایی که اجرای Migration لازم دارند (پس از مجوز)

### Migration و Guard

| # | آزمون |
|---|---|
| M1 | اجرا: Log دو ردیفه، Report چهار ردیفه، خودآزمایی ACL و TRUNCATE قبول |
| M2 | تغییر عمدی یک ستون از وضعیت هر یک از چهار تسک ثابت‌شده (مثلاً Status یا approval_state تسک `ttt`) → `premigration_mismatch`؛ بدون هیچ تغییر |
| M3 | Workflow سفارشی یا مسدود بدون Event → توقف |
| M4 | **مقایسهٔ کامل R7 با Guard:** برای هر ستون Guard (c)، تغییر همان ستون باید هم R7 را غیرخالی کند و هم Guard را متوقف کند (ده ستون × چهار تسک) |

### دسترسی

| # | آزمون |
|---|---|
| A1–A38 | مثل نسخهٔ سوم (عضویت، تسک شخصی، دایرکتوری، `use_submit`/`use_decide`، بازبین، مسدود، ACL، `category_retired`، `workflow_incomplete`) |
| A39 | تأیید والد با زیرتسک اجباری ناتمام → `subtasks_incomplete` |
| A40 | Override توسط بازبینی که مدیر نیست (بدون `tasks.manage.project` و `tasks.view.all`) → `forbidden` |
| A41 | Override مدیر با دلیل → تأیید؛ Audit `task.override_subtasks`؛ رویداد `task.override`؛ `p_reason` و `p_override_reason` جدا ثبت می‌شوند |
| A42 | Override بدون دلیل → `subtasks_incomplete` |
| A43 | حذف عضوی که فقط **بازبین اختصاصی** یک تسک باز است → `member_has_open_tasks` با `by_role.reviewer = 1` |
| A44 | حذف عضوی که فقط **همکار** یک تسک باز است → رد با `by_role.collaborator = 1` |
| A45 | جایگزینی بازبین، حذف همکار و تخصیص دوباره → Audit `task.reviewer_change`، `task.collaborator_remove` و `task.reassign`؛ سپس حذف عضو ✓ |
| A46 | بازبین اختصاصی پس از پایان عضویت → تصمیم و ویرایش بازبین `forbidden`. چون `remove_project_member` خودش مانع حذف است، `removed_at` در دادهٔ آزمون با SQL مستقیم گذاشته می‌شود. |
| A47 | عضو حذف‌شده که همکار تسک **بستهٔ** restricted بوده → تسک دیگر قابل دیدن نیست (۰ ردیف) |
| A48 | تسک مسدود در in_review: `decide_task` و `review_update_task` → `task_blocked`؛ `clear_task_blocked` → همان دور تصمیم می‌گیرد؛ `round_number` و Status ثابت‌اند |

### هم‌زمانی

| # | سناریو |
|---|---|
| C1–C7 | مثل نسخهٔ سوم |
| C8 | دو تأیید هم‌زمان روی والد با زیرتسک ناتمام، یکی با Override مدیر و یکی بدون → دقیقاً یکی موفق؛ دیگری `subtasks_incomplete` یا `already_decided`؛ Audit Override فقط برای برنده |
| C9 | حذف عضو هم‌زمان با **تخصیص مسئول** به همان عضو → یکی شکست می‌خورد |
| C10 | حذف عضو هم‌زمان با **تغییر بازبین** به همان عضو → یکی شکست می‌خورد |
| C11 | حذف عضو هم‌زمان با **افزودن همکار** همان عضو → یکی شکست می‌خورد؛ هیچ ردیفی برای عضو حذف‌شده نمی‌ماند |

### نسخه‌ها و تغییرناپذیری

| # | آزمون |
|---|---|
| V1–V10 | مثل نسخهٔ سوم |
| V11 | `update task_review_rounds set id = gen_random_uuid()` (حتی با postgres) → `round_immutable` |
| V12 | `truncate` روی هر پنج جدول تاریخی با `service_role` → خطای مجوز؛ با postgres → `immutable_row` (Trigger) |

### Rollback

| # | آزمون |
|---|---|
| R1–R6 | مثل نسخهٔ سوم |
| R7 | دادهٔ آزمون: تسکی در Status «مسدود» با Event قابل بازیابی → Migration (Flag) → کاربر `clear_task_blocked` → Rollback: تسک **برنمی‌گردد** (`unblocked_by_person`)، رویداد «بازگردانی» ثبت نمی‌شود |
| R8 | همان، بدون دخالت کاربر → برمی‌گردد و یک رویداد `unblocked` ثبت می‌شود |
| R9 | انتقال اضافه‌شده‌ای که مدیر پس از Migration حذف کرده یا تغییر داده → حفظ و گزارش با دلیل |
| R10 | گزارش Rollback: بخش‌های Restored و Kept جدا و شمارش‌ها در `workflow_rollback_runs` |

## ۱۴. خطاهای جدید

| گروه | خطاها |
|---|---|
| بررسی و Workflow | `use_submit`، `use_decide`، `round_required`، `stale_round`، `invalid_state`، `workflow_incomplete`، `what_required`، `already_submitted`، `not_submitted`، `subtasks_incomplete` (اکنون در تأیید هم) |
| مسدود | `task_blocked` (اکنون در تصمیم و ویرایش بازبین هم)، `already_blocked`، `not_blocked` |
| تخصیص و عضویت | `assignee_not_member`، `assignee_inactive`، `assignee_out_of_scope`، `reviewer_not_member`، `reviewer_inactive`، `collaborator_not_member`، `member_has_open_tasks` (سه نقش) |
| ویرایش و پیکربندی | `field_forbidden`، `invalid_changes`، `category_retired`، `status_required`، `archived` |
| تغییرناپذیری | `round_immutable`، `immutable_row`، `revision_request_mismatch`، `revision_request_missing` |
| Migration و Rollback | `premigration_mismatch`، `acl_check_failed`، `rollback_body_mismatch` |

## ۱۵. خارج از دامنه

- اعلان جدید.
- گسترش `profiles_select` یا دسترسی دیدن (بخش ۸.۵ فقط محدود می‌کند).
- Permission جدید.
- حذف فیزیکی وضعیت یا تاریخچه.
- تغییر Attendance و Leave.
- تغییر UI، که پس از اجرای Migration هم‌زمان با آن انجام می‌شود.

## ۱۶. تولید

جزئیات در [scripts/task-workflow-migration/README.md](../scripts/task-workflow-migration/README.md):
- `dump_functions.sh`: فقط‌خواندنی.
- `common.py`: انتظارات بازبینی‌شده و SQL مشترک.
- `gen_migration.py`، `gen_report.py` و `gen_rollback.py`.
- `static_check.py`: با `pglast` در یک venv جدا؛ وابستگی پروژه نیست.
